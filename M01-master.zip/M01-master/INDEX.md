ÍNDICE

    1.Deberes probar VirtualBox y Gandalf.
    
    2.Sistemas de particiones
          Reglas de partición en Windows

    3.Formas de arrancar
          USB/DVD
           DD
           PXE

    4.Configuración BIOS
          Boot Menu
          Boot Sequence
          Lan Boot
          IDE-AHCI

    5.Instalación Fedora 27

    6.Definir ASR, Dual Channel, DDR3, DDR4 y M.2

    7.Características CPU, RAM y Disco Duro

    8.Deberes que CPU, RAM y Disco Duro me compro

    9.Deberes “Que gráfica me compro”

    10.Placa Base
          10.1.Chipset
              North Bridge
              South Bridge

    11.Discos Duros
          M.2
          SATA
          SSD
          HDD
          
    12.RAM, Dual channel y Lanes
    
    13.Conversiones de bits a Bytes
          Tamaño
          Velocidad

    14.Pantallas
          Tasa de refresco (Hz)
          Resolución
          Bits de color
          Pulgadas
          
    15.Deberes calcular memoria RAM consumida por pantalla

    16.Deberes que PC me compro

    17.Fuente de alimentación, caja y refrigeración

    18.Git
         GitHub
         GitLab
         Que es MarkDown

    19.Deberes crear cuenta en Gitlab y Github y ponerlo en Markdown

    20.GNU/GPL en markdown

    21.Práctica: uso del tester y diagnóstico de PC

    22.Que contiene el MBR
         Tabla de particiones
         Boot Manager
         Firma

    23.Borrar y crear particiones en Fdisk

    24.Clusters y Sectores

    25.Formato de un Pen/DD
         FAT32

    26.Arquitectura 32 bits y 64 bits
         En sistemas operativos
         En CPU

    27.Repaso particiones

    28.Sistema Operativo Linux
         Kernel
         Run level
         XII/Wayland
         Window Manager
         Display Manager (GDM y Lightdm)
         Escritorio

     29.CLI, GUI i TUI

    30.Instalar Openbox

    31.Captura configuración de red en Windows

    32.Comando Watch, ionice, Ctrl+Z, bg, parametro & y significado ~

    33.Práctica fdisk desde archivo
         MBR
         GPT
