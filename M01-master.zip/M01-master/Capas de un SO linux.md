Capas de un Sistema Operativo Linux

Linux tiene bastantes capas como un Sistema Operativo. 
Como por ejemplo: El Kernel, la línea de comandos y el entorno gráfico.

 -Que es el KERNEL?

    Pues podriamos decir que el Kernel es el "núcleo", la parte central del Sistema Operativo.
    Su trabajo es es administrar de una forma segura el uso de la CPU y la RAM.
    Lo hace comunicandose con el hardware, el Kernel ocupa unos 150 MB en la memoria ram.


Línea de comandos (GUI-CLI)

    -Que es la GUI?
  
      La interfaz gráfica de usuario (GUI), es la interfaz que reemplaza el comando críptico por su representación gráfica.
      Es una forma de interfaz de usuario que permite interactuar con dispositivos electrónicos a través de iconos gráficos e 
      indicadores visuales en lugar de interfaces de usuario basadas en texto, etiquetas de comando escritas o navegación de texto. 
  
    -Que es la CLI? 
  
      La CLI es una interfaz de línea de comandos o un intérprete de lenguaje de comandos.
      También conocida como interfaz de usuario de línea de comandos y terminal.
      Es un medio que te permite interactuar con un programa de computadora donde el usuario (o cliente)
      envía comandos al programa en forma de líneas sucesivas de texto (líneas de comando).
      Esto te permite manipular el ordenador con instrucciones especificas en las lineas de comando.
 
  
  
  ESCRITORIOS 
  
    Hay muchos tipos de escritorios como por ejemplo :
    
                        GNOME : Consume muchos recursos 
                        Mate: Consume pocos recursos y se asemeja a windows
                        KDE: Es uno de los mas bonitos pero usa bastantes recursos
                        Cynamon : Se parece mucho a la interfaz de windows
                        LXDE
                        XFCE
                        Open Box : Uno de los que menos ram ocupa
      
        


  QUE SISTEMA OPERATIVO RECOMIENDO USAR? 
  
      -Fedora : Puede ir bien para una workstation, el problema es que no es GNU/GPL
      -Centos : Es muy bueno en temas de seguridad,  puede obtener la ventaja del software de servidor de código 
                 abierto como Apache Web Server, Samba, Sendmail, CUPS, vsFTPd, MySQL y BIND.
      -Debian: Va perfecto para una workstation con el escritorio Open Box , es GNU/GPL





